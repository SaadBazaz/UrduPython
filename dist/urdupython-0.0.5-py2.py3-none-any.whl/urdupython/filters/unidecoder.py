from unidecode import unidecode


def filter(input_str):
	return unidecode(input_str)
